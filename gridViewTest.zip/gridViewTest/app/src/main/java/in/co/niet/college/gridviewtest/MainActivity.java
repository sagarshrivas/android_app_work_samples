package in.co.niet.college.gridviewtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {


    GridView gridView;
    Spinner spinner;
    String[] clg={"iec","niet","glb","ggl","gbu","aktu","apeejey"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView=findViewById(R.id.gridView);
        spinner=findViewById(R.id.spinner);
        MyAdapter myAdapter=new MyAdapter(MainActivity.this,R.layout.child_layout);
        gridView.setAdapter(myAdapter);

        ArrayAdapter arrayAdapter=new ArrayAdapter(MainActivity.this,android.R.layout.support_simple_spinner_dropdown_item, R.id.spinner);
        spinner.setAdapter(arrayAdapter);
    }
}
