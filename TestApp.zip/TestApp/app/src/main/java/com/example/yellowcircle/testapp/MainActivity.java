package com.example.yellowcircle.testapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button setting,dialer,camera,compose,browser,mail;
    ImageView imageView;
    public static final int PICK_IMAGE = 1;
    public static final int CAMERA_PICK_IMAGE = 2;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {

            if (requestCode== PICK_IMAGE && resultCode == RESULT_OK) {
                Uri imageUri = data.getData();

                // Bitmap bitmap=MediaStore.Images.Media.getBitmap(getContentResolver());
                //imageView.setImageBitmap(bitmap);
                imageView.setImageURI(imageUri);
            }
            else if(requestCode==CAMERA_PICK_IMAGE && resultCode==RESULT_OK){
            Bitmap bitmap=(Bitmap)data.getExtras().get("data");
            imageView.setImageBitmap(bitmap);
            }
        }catch(Exception e){

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setting=findViewById(R.id.Setting);
        dialer=findViewById(R.id.Dialer);
        camera=findViewById(R.id.Camera);
        compose=findViewById(R.id.Compose);
        browser=findViewById(R.id.Browser);
        mail=findViewById(R.id.Mail);
        imageView=findViewById(R.id.imageView);

        setting.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent(Settings.ACTION_SETTINGS);
                        startActivity(intent);
                    }
                }
        );

        dialer.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent();
                        intent.setAction(Intent.ACTION_DIAL);//=new Intent(android.provider.Settings.ACTION_DIAL);
                        startActivity(intent);

                    }
                }
        );

        camera.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent();
                        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent,CAMERA_PICK_IMAGE);

                    }
                }
        );

        compose.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
                    }
                }
        );

        browser.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com"));
                        startActivity(browserIntent);
                    }
                }
        );

        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                startActivity(sendIntent);

            }
        });
    }
}
