package com.example.yellowcircle.lifecycle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button button;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("onCreate", "on create executed");
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent;
                        intent = new Intent(MainActivity.this, NextActivity.class);
                        startActivity(intent);
                    }
                }
        );
        editText=findViewById(R.id.editText);
        //create animation object
        Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.cw_anim);
        //apply animation ono the elementspbbbbbbbbbbbbbb
        editText.startAnimation(animation);
    }

        public void onResume() {

            super.onResume();
            System.out.println("on resume executed");
        }

        public void onStart(){
            super.onStart();
            System.out.println("on start executed");
        }


}

