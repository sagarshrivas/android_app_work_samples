package com.example.yellowcircle.lifecycle;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }

    @Override
    public void onResume() {

        super.onResume();
        Thread thread=new Thread(){
            public void run(){

                try{
                    Thread.sleep(3000);
                }catch (Exception e){

                }
                startActivity(new Intent(SplashAct.this,MainActivity.class));
            }
        };
        thread.start();
    }
}
