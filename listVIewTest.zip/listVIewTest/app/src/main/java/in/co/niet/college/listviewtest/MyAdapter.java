package in.co.niet.college.listviewtest;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sagar on 24/2/18.
 */

public class MyAdapter extends ArrayAdapter {
    String[] name={"bob","kelvin","stuart","jimmy","bello"};
    int[] age={10,12,13,11,15};
    int[] pic={R.drawable.min1,R.drawable.min2,R.drawable.min3,R.drawable.min4,R.drawable.min5};
    int child_layout;
    Context ctx;

    public MyAdapter(@NonNull Context context, int resource) {
        super(context, resource);
        child_layout=resource;
        ctx=context;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView=LayoutInflater.from(ctx).inflate(child_layout,null);
        ImageView iv=convertView.findViewById(R.id.iv);
        TextView nameTextView=convertView.findViewById(R.id.textName);
        TextView ageTextView=convertView.findViewById(R.id.textAge);
        iv.setImageResource(pic[position]);
        nameTextView.setText(name[position]);
        ageTextView.setText(age[position]+"");
        return convertView;


    }
}
